  </div>
  <!------ End content ---------->
</div>
</div>

<!-- footer 
<div class="footer">
  <p>Footer</p>
</div>
-->

</body>
</html>
